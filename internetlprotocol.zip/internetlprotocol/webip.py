import requests

api_key = 'YOUR_API_KEY'
link = 'https://your-link.com'

response = requests.post('https://api-ssl.bit.ly/v4/shorten', 
                         headers={'Authorization': f'Bearer {api_key}'}, 
                         json={'long_url': link})

print(response.json()['link'])